import { Component, OnInit } from "@angular/core";
import { TableCol } from "src/app/components/table/table.component";
import { DataService } from "src/app/services/data.service";
import { Router } from "@angular/router";
import { Simulation } from "src/app/interfaces/Simulation";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
})
export class HomeComponent implements OnInit {
  cols: TableCol[] = [
    {
      name: "Name",
      key: "simName",
    },
    {
      name: "Type",
      key: "type",
    },
  ];
  constructor(public data: DataService, private router: Router) {}

  ngOnInit(): void {}

  showDetail(item: Simulation) {
    this.router.navigate(["detail", item._id.$oid]);
  }
}
