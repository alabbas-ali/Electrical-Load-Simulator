import { DatePipe } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { TableCol } from "src/app/components/table/table.component";
import { Simulation } from "src/app/interfaces/Simulation";
import { DataService } from "src/app/services/data.service";
import numeral from "numeral";
import { ChartDataSets } from "chart.js";

type AvailabilityActivity = { name: string; start: string; end: string }[];
type Appliance = {
  type: string;
  powerInputOn: string;
  powerInputOff: string;
  duration: number;
};
@Component({
  selector: "app-detail",
  templateUrl: "./detail.component.html",
  styleUrls: ["./detail.component.scss"],
  providers: [DatePipe],
})
export class DetailComponent implements OnInit {
  availabilities: AvailabilityActivity[] = [];
  appliances: Appliance[] = [];
  loadCurve: ChartDataSets[] = [];
  loadCurveLabels: string[] = [];

  availabilitiesCols: TableCol[] = [
    {
      name: "Activity",
      key: "name",
    },
    {
      name: "Start",
      key: "start",
    },
    {
      name: "End",
      key: "end",
    },
  ];
  appliancesCols: TableCol[] = [
    {
      name: "Type",
      key: "type",
    },
    {
      name: "Power Input on",
      key: "powerInputOn",
    },
    {
      name: "Power Input Off",
      key: "powerInputOff",
    },
    {
      name: "Duration",
      key: "duration",
    },
  ];

  constructor(
    private activatedRoute: ActivatedRoute,
    private datePipe: DatePipe,
    private data: DataService
  ) {
    const id = this.activatedRoute.snapshot.params.id;
    const simulation = this.data.getById(id);

    this.availabilities = this.getAvailabilities(simulation);
    this.appliances = this.getAppliances(simulation);
    this.loadCurve = this.getLoadCurve(simulation);
    this.loadCurveLabels = this.getLoadCurveLabels(simulation);
  }

  ngOnInit(): void {}

  private getAvailabilities(simulation: Simulation) {
    return (
      simulation.availabilities?.map((availability) =>
        availability.activities.map((activity) => ({
          name: activity.name,
          start: this.transformDate(activity.start.$date),
          end: this.transformDate(activity.end.$date),
        }))
      ) ?? []
    );
  }

  private getAppliances(simulation: Simulation) {
    return (
      simulation.appliances
        ?.map((appliance) =>
          appliance.operationalModes.map((mode) => ({
            type: appliance.type,
            powerInputOn: this.transformPowerInput(mode.powerInputOn),
            powerInputOff: this.transformPowerInput(mode.powerInputOff),
            duration: mode.duration,
          }))
        )
        .reduce((acc, item) => acc.concat(item), []) ?? []
    );
  }

  private getLoadCurve(simulation: Simulation) {
    const { measurements = [] } = simulation.resultLoadCurve;

    const loadMeasurements = measurements.map(({ value }) => value);
    const loadMeasurementsTotal = loadMeasurements.reduce(
      (acc, cur) => acc + cur,
      0
    );

    const lightingLoad = measurements.map(({ lightingValue }) => lightingValue);
    const lightingLoadTotal = lightingLoad.reduce((acc, cur) => acc + cur, 0);

    const occupancy = measurements.map(({ occupancy }) => occupancy);
    const activeOccupancy = measurements.map(
      ({ activeOccupancy }) => activeOccupancy
    );

    return [
      {
        label: `Load Curve, Total: ${loadMeasurementsTotal}`,
        data: loadMeasurements,
        fill: false,
      },
      {
        label: `Lighting Load, Total: ${lightingLoadTotal}`,
        data: lightingLoad,
        fill: false,
      },
      {
        label: "Occupancy",
        data: occupancy,
        fill: false,
      },
      {
        label: "Active Occupancy",
        data: activeOccupancy,
        fill: false,
      },
    ];
  }

  private getLoadCurveLabels(simulation: Simulation) {
    return simulation.resultLoadCurve.measurements.map((item) =>
      numeral(item.time).format("00:00:00")
    );
  }

  private transformDate(date: string) {
    return this.datePipe.transform(date, "shortTime");
  }

  private transformPowerInput(input: number) {
    return numeral(input).format("0.0");
  }
}
