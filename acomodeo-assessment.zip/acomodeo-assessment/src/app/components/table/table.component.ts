import { Component, Input, Output, EventEmitter } from "@angular/core";

export type TableCol = {
  name: string;
  key: string;
};

@Component({
  selector: "app-table",
  templateUrl: "./table.component.html",
  styleUrls: ["./table.component.scss"],
})
export class TableComponent {
  @Input() data: {}[];
  @Input() cols: TableCol[];
  @Input() clickable = false;

  @Output() rowClicked = new EventEmitter();

  constructor() {}

  click(row) {
    if (this.clickable) {
      this.rowClicked.emit(row);
    }
  }
}
