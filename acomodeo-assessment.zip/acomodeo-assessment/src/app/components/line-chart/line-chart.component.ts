import { Component, Input, OnInit } from "@angular/core";
import { ChartDataSets, ChartOptions } from "chart.js";

@Component({
  selector: "app-line-chart",
  templateUrl: "./line-chart.component.html",
  styleUrls: ["./line-chart.component.scss"],
})
export class LineChartComponent implements OnInit {
  @Input() datasets: ChartDataSets[] = [];
  @Input() labels: string[] = [];
  @Input() title: string;

  options: ChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      yAxes: [
        {
          type: "logarithmic",
          ticks: {
            min: 0,
            max: 10000,
            callback: function (value, index, values) {
              return value;
            },
          },
        },
      ],
    },
  };

  constructor() {}

  ngOnInit(): void {}
}
