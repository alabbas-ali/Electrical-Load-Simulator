import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router } from "@angular/router";
import { DataService } from "../services/data.service";

@Injectable({
  providedIn: "root",
})
export class DetailGuard implements CanActivate {
  constructor(private data: DataService, private router: Router) {}
  canActivate(route: ActivatedRouteSnapshot): boolean {
    const id = route.params.id;
    if (!id) {
      this.router.navigateByUrl("");
      return false;
    }

    const simulation = this.data.getById(id);
    if (!simulation) {
      this.router.navigateByUrl("");
      return false;
    }

    return true;
  }
}
