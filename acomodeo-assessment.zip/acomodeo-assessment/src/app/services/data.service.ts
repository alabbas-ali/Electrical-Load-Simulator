import { Injectable } from "@angular/core";
import JsonData from "../../assets/hous_test.json";
import { Simulation } from "../interfaces/Simulation";

@Injectable({
  providedIn: "root",
})
export class DataService {
  public readonly simulations: Simulation[];
  constructor() {
    this.simulations = JsonData;
  }

  getById(id: string): Simulation | undefined {
    return this.simulations.find((item) => item._id.$oid === id);
  }
}
