export interface Simulation {
  _id: Id;
  simName: string;
  type: string;
  resultLoadCurve: ResultLoadCurve;
  availabilities?: AvailabilitiesEntity[] | null;
  appliances?: AppliancesEntity[] | null;
}
export interface Id {
  $oid: string;
}
export interface ResultLoadCurve {
  name: string;
  description: string;
  creationDate: Date;
  measurements?: MeasurementsEntity[] | null;
}
export interface Date {
  $date: string;
}
export interface MeasurementsEntity {
  time: number;
  value: number;
  lightingValue: number;
  activeOccupancy: number;
  occupancy: number;
}
export interface AvailabilitiesEntity {
  _id: Id;
  name: string;
  type: string;
  activities?: ActivitiesEntity[] | null;
  creationDate: Date;
}
export interface ActivitiesEntity {
  name: string;
  start: Date;
  end: Date;
  type: string;
}
export interface AppliancesEntity {
  _id: Id;
  name: string;
  type: string;
  description: string;
  creationDate: Date;
  operationalModes?: OperationalModesEntity[] | null;
}
export interface OperationalModesEntity {
  name: string;
  description: string;
  powerInputOn: number;
  powerInputOff: number;
  restartDelay: number;
  scaleFactor: number;
  duration: number;
  leftCycleTime: number;
  leftRestartDelay: number;
  loadCurve?: LoadCurve | null;
}
export interface LoadCurve {
  name: string;
  description: string;
  measurements?: MeasurementsEntity[] | null;
}
