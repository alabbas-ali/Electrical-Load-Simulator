# Acomodeo Assessment

## Libraries

- [Angular 11.2](https://angular.io/)
- [TailwindCSS](https://tailwindcss.com/) for styling
- [ng2-charts](https://github.com/valor-software/ng2-charts) and [Chart.js](https://www.chartjs.org/) for displaying charts
- [numeral](http://numeraljs.com/) for formatting the time labels in the chart

## Installation

Run `npm i` to install all dependencies.

## Development server

Run or `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.
